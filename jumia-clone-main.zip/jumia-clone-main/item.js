let yourLocation:



function yourLocationChangeHandler(event) {
    console.log("Even is:>", event.target.value);
    yourLocation =  event.target.value;
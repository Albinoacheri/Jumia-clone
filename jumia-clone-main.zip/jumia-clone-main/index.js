let yourLocation;


function nairobiMombasaNakuruWajirTurkanaChangeHandler(event){
    console.log("Even is:>", event.target.value);
    nairobiMombasaNakuruWajirTurkana =  event.target.value;
}